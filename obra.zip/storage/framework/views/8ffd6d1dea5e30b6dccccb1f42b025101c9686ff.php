
<div class="menu open">



    <div class="menu-wrapper">
        <a class="menu-title">menu</a>

        <div class="menu-container">
            <div class="nav-column">
                <form id="search-form" class="search-form" method="GET" action="">
                    <div class="row">
                        <div class="col-xs-10 col-xs-offset-1">
                            <div class="group">
                                <input type="text" class="input-field input-primary input-icon-right" name="search" required>
                                <span class="fa fa-search"></span>
                                <span class="input-highlight"></span>
                                <span class="input-bar"></span>
                                <label>Buscar</label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="nav-column">
                <nav>
                    <ul class="nav-options">
                        <li class="nav-option">
                            <a class="nav-text">About</a>
                        </li>
                        <li class="nav-option">
                            <a class="nav-text">Catálogo</a>
                        </li>
                        <li class="nav-option">
                            <a class="nav-text">Blog</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    </div>

</div>
