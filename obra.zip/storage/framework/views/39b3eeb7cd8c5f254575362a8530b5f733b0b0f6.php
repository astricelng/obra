<?php $__env->startSection('logo-variant'); ?>
    <img class="enowledge-logo" src="<?php echo e(asset('assets/www/images/logo-dark.png')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="about-intro">

        <div class="about-intro__bgc"></div>

        <div class="about-intro__title">
            <h1 class="base-title about-title title-white">
                Bienvenido
            </h1>
            <h2 class="base-title about-subtitle title-white">
                A Enowledge
            </h2>
        </div>

    </section>

    <section class="about-content">

        <div class="about-content__wrapper">
            <div class="about-content__column">
                <p class="base-text about-text">
                    Enowledge es una comunidad que fomenta
                    la cultura del vino. Nos encanta compartir
                    el conocimiento de una forma amena y plural.
                </p>
                <p class="base-text about-text">
                    Ofrecemos los mejores contenidos, cursos
                    y experiencias enológicas para acercarte
                    al mundo del vino, tanto presenciales
                    como en línea.
                </p>
            </div>

            <div class="about-content__column">
                <p class="base-text about-text">
                    <strong>Creemos en la democratización de la
                    cultura del vino</strong> para ponerlo al alcance de
                    todas las personas, independientemente de
                    su poder adquisitivo, brindándoles tanto un
                    elemento de convivencia social como una
                    herramienta  de conocimiento académico.
                </p>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('www.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>