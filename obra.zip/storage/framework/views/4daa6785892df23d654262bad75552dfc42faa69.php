<ul class="social-media">
    <li>
        <a href="https://www.facebook.com/Enowledge" target="_blank" class="social-icon"><span class="fa fa-facebook"></span></a>
    </li>
    <li>
        <a href="https://twitter.com/enowledge" target="_blank" class="social-icon"><span class="fa fa-twitter"></span></a>
    </li>
    <li>
        <a href="https://www.instagram.com/enowledge/" target="_blank" class="social-icon"><span class="fa fa-instagram"></span></a>
    </li>
</ul>