
<header class="header">
    <div class="logo-container">
        <a href="<?php echo e(route('web.home')); ?>">
            <?php echo e($logo); ?>

        </a>
    </div>
</header>

<div class="nav-trigger">
    <div class="trigger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</div>
