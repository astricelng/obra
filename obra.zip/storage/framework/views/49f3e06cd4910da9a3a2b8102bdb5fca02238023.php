
<footer>

    <div class="footer-logo text-center mb20">
        <img class="enowledge-logo" src="<?php echo e(asset('assets/www/images/logo-light.png')); ?>">
    </div>

    <div class="container-fluid">

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-9 col-md-9">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <ul class="sitemap-links">
                            <li><a>¿Quiénes somos?</a></li>
                            <li><a>Paulina Granados</a></li>
                            <li><a>Blog</a></li>
                            <li><a>Suscribirse</a></li>
                        </ul>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <ul class="sitemap-links">
                            <li><a>Catálogo</a></li>
                            <li><a>Ingresar</a></li>
                            <li><a>Soporte</a></li>
                            <li><a>Descargas</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 politics-column">
                <p>
                    <a href="" class="footer-text">
                        Políticas de privacidad
                    </a>
                    <br>
                    <a href="" class="footer-text">
                        Políticas de cookies
                    </a>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 text-center">
                <?php echo $__env->make('www.layouts.components._social-icons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-xs-12 text-center">
                <p class="footer-text">
                    <small>Todos los derechos reservados &#169; 2017</small>
                </p>
            </div>
        </div>

    </div>

</footer>
