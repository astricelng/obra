<?php
    
return [
    
    'locales' => [
        'en' => 'English',
        'es' => 'Español',
    ]
    
];